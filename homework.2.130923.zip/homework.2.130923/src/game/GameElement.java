package game;

public enum GameElement {
    ROCK,
    SCISSORS,
    PAPER
}
