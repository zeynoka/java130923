import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("How many years have you been married?");
        int anniversary = new Scanner(System.in).nextInt();
        String anniversaryYear = switch (anniversary){
            case 1 -> "Paper";
            case 2 -> "Cotton";
            case 3 -> "Leather";
            case 4 -> "Fruit";
            case 5 -> "Wooden";
            case 6 -> "Sugar";
            case 7 -> "Copper";
            case 8 -> "Bronze";
            case 9 -> "Willow";
            case 10 -> "Tin";
            default -> "i dont know";
        };
        System.out.println(anniversaryYear);

    }
}